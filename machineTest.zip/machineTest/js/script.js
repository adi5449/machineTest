$(document).ready(function () {
    $('#addBtn').click(function () {
        $('#addMemberModal').modal();
    });

    $('#addMemberForm').submit(function (e) {
        e.preventDefault();

        let name = $('#memberName').val().trim();
        let parent = $('#parentSelect').val();

        if (name === '' || !/^[a-zA-Z\s]+$/.test(name)) {
            alert('Enter a valid name.');
            return;
        }

        $.post('add_member.php', {
            name: name,
            parent_id: parent
        }, function (response) {
            let data = JSON.parse(response);

            if (data.status === 'success') {
                let newNode = `<li data-id="${data.id}">${data.name}</li>`;

                if (data.parent_id === null) {
                    if ($('#memberTree > ul').length === 0) {
                        $('#memberTree').append("<ul>" + newNode + "</ul>");
                    } else {
                        $('#memberTree > ul').append(newNode);
                    }
                } else {
                    let parentNode = $(`li[data-id='${data.parent_id}']`);
                    if (parentNode.children("ul").length === 0) {
                        parentNode.append("<ul>" + newNode + "</ul>");
                    } else {
                        parentNode.children("ul").append(newNode);
                    }
                }

                $.modal.close();
                $('#addMemberForm')[0].reset();
            } else {
                alert("Error: " + data.message);
            }
        });
    });
});
