<?php
require_once 'classes/Database.php';
require_once 'classes/Member.php';

$db = (new Database())->getConnection();
$member = new Member($db);

$name = $_POST['name'] ?? '';
$parent_id = $_POST['parent_id'] ?? null;
$parent_id = $parent_id === "" ? null : (int)$parent_id;

if (empty($name) || !preg_match("/^[a-zA-Z\s]+$/", $name)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid name']);
    exit;
}

try {
    $id = $member->insert($name, $parent_id);
    echo json_encode(['status' => 'success', 'id' => $id, 'name' => $name, 'parent_id' => $parent_id]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
