<?php
require_once 'classes/Database.php';
require_once 'classes/Member.php';

$db = (new Database())->getConnection();
$member = new Member($db);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Member Tree</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-modal@0.9.2/jquery.modal.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/jquery-modal@0.9.2/jquery.modal.min.css" />
</head>
<body>

<h2>Members List</h2>
<div id="memberTree">
    <?php $member->buildTree(); ?>
</div>

<br><button id="addBtn">Add Member</button>

<div id="addMemberModal" class="modal">
    <h2>Add Member</h2>
    <form id="addMemberForm">
        <label>Parent:</label>
        <select name="parent_id" id="parentSelect">
            <option value="">-- None --</option>
            <?php
            foreach ($member->getAllMembers() as $mem) {
                echo "<option value='{$mem['Id']}'>" . htmlspecialchars($mem['Name']) . "</option>";
            }
            ?>
        </select><br><br>

        <label>Name:</label>
        <input type="text" name="name" id="memberName" required /><br><br>

        <button type="submit">Save Changes</button>
    </form>
</div>

<script src="js/script.js"></script>
</body>
</html>
