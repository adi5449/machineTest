<?php
class Member {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getMembers($parentId = null) {
        $query = "SELECT * FROM Members WHERE ParentId " . 
                 (is_null($parentId) ? "IS NULL" : "= :parentId");
        $stmt = $this->conn->prepare($query);
        if (!is_null($parentId)) {
            $stmt->bindParam(':parentId', $parentId, PDO::PARAM_INT);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function buildTree($parentId = null) {
        $members = $this->getMembers($parentId);
        if ($members) {
            echo "<ul>";
            foreach ($members as $member) {
                echo "<li data-id='{$member['Id']}'>" . htmlspecialchars($member['Name']);
                $this->buildTree($member['Id']);
                echo "</li>";
            }
            echo "</ul>";
        }
    }

    public function getAllMembers() {
        $stmt = $this->conn->prepare("SELECT Id, Name FROM Members");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function insert($name, $parentId) {
        $query = "INSERT INTO Members (Name, ParentId) VALUES (:name, :parentId)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':parentId', $parentId);
        $stmt->execute();
        return $this->conn->lastInsertId();
    }
}
